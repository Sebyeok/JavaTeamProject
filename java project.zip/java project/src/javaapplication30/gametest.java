package javaapplication30;

import java.util.Scanner;
import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.Color;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JMenuBar;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.net.*;

class number{
	public  static int count;
	  public  static int enemy;
	  public  static int point;
	  public  static int e;
	  public  static int map;
	
	  public static int timelimit;
	number(int c){
		  map=c;
		  if(c==0)
		  {enemy=6;
		  e=1;
		  timelimit=60;
		  }
		  if(c==1)
		  {enemy=4;
		  e=2;
		  timelimit=40;
		  }
		  if(c==2)
		  {enemy=2;
		  e=3;
		  timelimit=20;
		  }
	
	}
	  }

class Ex5 extends JFrame{
    Ex5(){
        this.setTitle("��� ����");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        GamePanel p = new GamePanel();
        this.add(p);
        
        this.setLocationRelativeTo(null);
        this.setSize(800,800);
        this.setResizable(false);
        this.setVisible(true);
        p.startGame();
    }
}

class GamePanel extends JPanel implements KeyListener{
	
	GamePanel k;
	number num;
	TimeThread timethread = new TimeThread();
	TargetThread[] targetThread = new TargetThread[num.enemy];
    TargetThread2 targetThread2;
    TargetThread3 targetThread3;
    TargetThread4 targetThread4;
    JLabel pointshow=new JLabel();
    JLabel time=new JLabel();
    JLabel gameover=new JLabel();
    JLabel gameend= new JLabel();

    JTextField ioField=new JTextField();
    JLabel base = new JLabel();
    JLabel bullet = new JLabel();
    JLabel[] target = new JLabel[num.enemy];
    JLabel target2 = new JLabel();
    JLabel target3= new JLabel();
    JLabel target4= new JLabel();
    int  timelimit= num.timelimit;
    int both;
    JScrollPane scrollPane;
   
    ImageIcon img;
    ImageIcon img2;
    ImageIcon img3;
    ImageIcon img4;
    ImageIcon img5;
    ImageIcon img6;
    ImageIcon img7;
    ImageIcon img8;
    ImageIcon img9;
	BaseThread baseThread;
	BulletThread bulletThread = null;
    boolean direction; // true : Right , false : Left
	boolean fired; // true : fired , false : not fired yet
    //AudioClip sound;

    GamePanel()
    {
    	 if(num.map==0)
         {
             img = new ImageIcon("./�ɰ�.png");
             img2 = new ImageIcon("./����.png");
             img3 = new ImageIcon("./���.png");
             img4 = new ImageIcon("./����.png");
             img5 = new ImageIcon("./The End2.png");
             img6 = new ImageIcon("./�ٴ�.jpg"); 
             img7 = new ImageIcon("./Game Over.png");
             img8 = new ImageIcon("./�����.png");
             img9 = new ImageIcon("./����.png");
         }
        if(num.map==1) {
        img = new ImageIcon("./����.png");
        img2 = new ImageIcon("./����.png");
        img3 = new ImageIcon("./�����䳢.png");
        img4 = new ImageIcon("./��.png");
        img5 = new ImageIcon("./The End3.png");
        img6 = new ImageIcon("./��ٳ�.jpg");
        img7 = new ImageIcon("./Game Over2.png");
        img8 = new ImageIcon("./���Ѿ�.png");
        img9 = new ImageIcon("./����.png");
        }
      
        	if(num.map==2)
        	{
                img = new ImageIcon("./�⺻����.png");
                img2 = new ImageIcon("./����������.png");
                img3 = new ImageIcon("./�ذ�.png");
                img4 = new ImageIcon("./����.png");
                img5 = new ImageIcon("./The End.png");
                img6 = new ImageIcon("./����.png");
                img7 = new ImageIcon("./Game Over3.png");
                img8 = new ImageIcon("./bullet.png");
                img9 = new ImageIcon("./base.png");
        	}
        	this.setLayout(null);
        	
            base.setSize(40,40);
    		base.setIcon(img9);
    		base.setLocation(380, 520);
            base.requestFocus();
    		base.addKeyListener(this);
    		
    	    
    		/*JPanel background = new JPanel(){
    		 public void paintComponent(Graphics g) {
                 // Approach 1: Dispaly image at at full size
                 g.drawImage(img.getImage(),0,0, 800, 800, null);
                 // Approach 2: Scale image to size of component
                 // Dimension d = getSize();
                 // g.drawImage(icon.getImage(), 0, 0, d.width, d.height, null);
                 // Approach 3: Fix the image position in the scroll pane
                 // Point p = scrollPane.getViewport().getViewPosition();
                 // g.drawImage(icon.getImage(), p.x, p.y, null);
                 setOpaque(true); //�׸��� ǥ���ϰ� ����,�����ϰ� ����
                 super.paintComponent(g);
             }
    		};
    		add(background);
    		background.setVisible(true);*/
        for(int i=0;i<targetThread.length;i++)
        {
        	 target[i] = new JLabel(img);
             target[i].setSize(img.getIconWidth(),img.getIconHeight());
             this.add(target[i]);
        }
        
      
        target2 = new JLabel(img2);
        target3 = new JLabel(img3);
        target4 = new JLabel(img4);
        //�̹��� ũ�⸸ŭ ���̺� ũ�� ����
        target2.setSize(img2.getIconWidth(),img2.getIconHeight());
      //  System.out.println(""+img2.getIconWidth()+"  "+img2.getIconHeight());
        // Ȯ�ΰ�� ũ�� 96 96
        this.add(target2);
        
        target3.setSize(img3.getIconWidth(),img3.getIconHeight());
        
        this.add(target3);
        
        target4.setSize(img4.getIconWidth(),img4.getIconHeight());
       
        this.add(target4);
        pointshow.setSize(100,50);
        time.setSize(100,50);
        //ioField.setSize(50,50);
        
        this.add(pointshow);
        this.add(time);
        //this.add(ioField);
        gameend.setIcon(img5);
	       gameend.setSize(img5.getIconWidth(),img5.getIconHeight());
	    
	     gameend.setVisible(false);//�̷��� �� �� �ۿ� �������ϴ�.
	     
      
        bullet.setSize(img8.getIconWidth(),img8.getIconHeight());
        bullet.setIcon(img8);
      
       
        this.add(base);
        this.add(bullet);
        this.add(gameover);
        this.add(gameend);
        //URL url = Ex5.class.getResource("LASER.wav");
        //sound = Applet.newAudioClip(url);
        /////////////
     
        JLabel lbImage1  = new JLabel(img6);
	     lbImage1.setSize(800,800);
		this.add(lbImage1);
		lbImage1.setVisible(true);
        /////////////
    }
    
    public void startGame(){
        base.setLocation(this.getWidth()/2-20, this.getHeight()-40);
        bullet.setLocation(this.getWidth()/2-5, this.getHeight()-50);
        
        for(int i=0;i<targetThread.length;i++)
        {
        	target[i].setLocation(0, 0);
        }
        target2.setLocation(-400, -400);
        target3.setLocation(-400, -400);
        target4.setLocation(-400, -400);
        pointshow.setLocation(350,0);
        time.setLocation(300,0);
        //ioField.setLocation(400,0);
        //Ÿ���� �����̴� ������
        
        
        
        timethread.start();
      
        	
        for(int i=0;i<targetThread.length;i++)
        {
        	targetThread[i] = new TargetThread(target[i]);
        	targetThread[i].start();
        }
        
        
        targetThread2 = new TargetThread2(target2);
    		//targetThread2.start();
    	
        targetThread3 = new TargetThread3(target3);
    		//targetThread3.start();
    	
        targetThread4 = new TargetThread4(target4);
    		//targetThread4.start();
    
        
        
        //���̽��� ������ �ΰ� ����Ű �Է¿� ���� bullet������ ����
        base.requestFocus();
        base.addKeyListener(this);
            
                    
                
            }

       
            
            
      
    
    /*public void startGame2(){
    	if(num.count==2)
        { targetThread2 = new TargetThread2(target2);
    		targetThread2.start();}
    	if(num.count==2)
        { targetThread3 = new TargetThread3(target3);
    		targetThread3.start();}
    	if(num.count==2)
        { targetThread4 = new TargetThread4(target4);
    		targetThread4.start();}
    }*/
   class TimeThread extends Thread{
	  
		
		public TimeThread(){
			
		}
		public void run() {
			while(true) {
				
				try 
				{
					time.setText(Integer.toString(timelimit));
					sleep(1000);
					timelimit--;
					if(timelimit<0)
					{
						break;
					}
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
			 KillThread();
			  gameover.setIcon(img7);
		        gameover.setSize(img7.getIconWidth(),img7.getIconHeight());
			     gameover.setOpaque(true); //Opaque���� true�� �̸� ������ �־�� ������ ����ȴ�.
			    
		     gameover.setVisible(true);
		    
		}
		
    }
   void KillThread()
   {
	   for(int i=0;i<num.enemy;i++) {
		   targetThread[i].stop();
	   target[i].setLocation(-300, -300);
       target[i].setVisible(false);
   }
	   targetThread2.stop();
	   target2.setLocation(-300, -300);
       target2.setVisible(false);
	   targetThread3.stop();
	   target3.setLocation(-300, -300);
       target3.setVisible(false);
	   targetThread4.stop();
	   target4.setLocation(-300, -300);
       target4.setVisible(false);
       time.setVisible(false);
       pointshow.setVisible(false);
       base.setVisible(false);
       bullet.setVisible(false);
	  // bulletThread.stop();
	  // baseThread.stop();
   }
   void KillThread2()
   {
	   
	   for(int i=0;i<num.enemy;i++)
		   targetThread[i].stop();
	   for(int i=0;i<num.enemy;i++)
       {
       target[i].setLocation(-96, -96);
       target[i].setVisible(false);
       }//�ױ� ���� �������� ��ġ�� ���ع����� ��ġ ���ϴ� �� �װ������� �ؾ��ϳ׿�
	  
	 
   }

   void KillThread4()
   {
	   target2.setLocation(-400, -400);//Ÿ�ٽ�����ó�� �̹����� �ʾ������� �׳� ��ġ�� �ٲ���Ƚ��ϴ�.
	   target3.setLocation(-400, -400);
	   target4.setLocation(-400, -400);
	   target2.setVisible(false);
	   target3.setVisible(false);
	   target4.setVisible(false);
	   time.setLocation(-400,400);
	   time.setVisible(false);
	   pointshow.setLocation(-400,400);
	   pointshow.setVisible(false);
	   time.setVisible(false);
	   base.setVisible(false);
       bullet.setVisible(false);
	     
	    
	     gameend.setVisible(true);
	
	  
   }
    class TargetThread extends Thread{
        JLabel target;
        int d=20;
       
        int xx;
        int yy;
        TargetThread(JLabel target){
        	int xx = (int) Math.floor(Math.random() * 800);
        	int yy = (int) Math.floor(Math.random() * 600);
            this.target=target;
            target.setLocation(xx, yy);
        }
        public void run(){
        	int a=5;
        	int b=5;
        	int d=20;
            while(true){
            	/*	
            	    if(c.count==6)
            	  	{
            	  	a = (int) Math.floor(Math.random() * 9);
            	  	}
            	*/
            	if(num.count>=4)
            	{
            		if(num.count>=6)
            		{d=10;}
            		else
            		{d=15;}
            	}
                int x=target.getX()+a;//5�ȼ��� �̵�
                int y=target.getY();
                if(num.count>=2)
                {y=target.getY()+b;}                
                //������ ������ �������
                if(x>GamePanel.this.getWidth())
                	{
                	a=-5;
                    target.setLocation(GamePanel.this.getWidth(), y);
                    }
                //������ �ȿ� ������� 5�ȼ��� �̵�
                else
                    target.setLocation(x, y);
                
                if(x<0)
            	{
                	a=5;
                target.setLocation(5, y);}
                else
                    target.setLocation(x, y);
//////////////////////////////////////////////////////////////////////////////////////
                
                if(y>600)
            	{
            	b=-5;
                target.setLocation(x, 600);
                }
            //������ �ȿ� ������� 5�ȼ��� �̵�
            else
                target.setLocation(x, y);
            
            if(y<0)
        	{
            	b=5;
            target.setLocation(x, 0);}
            else
                target.setLocation(x, y);
            
            
////////////////////////////////////////////////////////////////////////////////////
                //0.02�ʸ��� �̵�
                try{
                    sleep(d);
                }
                //�����尡 �װԵǸ� �ʱ� ��ġ�� ��ġ�ϰ�, 0.5�ʸ� ��ٸ���.
                catch(Exception e){
                	
                    target.setLocation(5, y);
                    num.point++;
                    timelimit+=6/num.e;
                	num.count++;
                    pointshow.setText("����:"+num.point);
                    try{
                        sleep(500);
                    }
                    catch(Exception e2){}
                	
                	
                	
                
                }
            }
        }
    }
    
    class TargetThread2 extends Thread{
    
    	JLabel target;
        int d=20;
       
        int xx;
        int yy;
        
        
        TargetThread2(JLabel target){
        
        	int xx = (int) Math.floor(Math.random() * 800);
        	int yy = (int) Math.floor(Math.random() * 600);
            this.target=target;
            if(num.count==2) {target.setLocation(xx, yy);}
        	
        }
        
        public void run(){
        	 {
        	int a=5;
        	int b=5;
        	int d=15;
            while(true){
            	/*	
            	    if(c.count==6)
            	  	{
            	  	a = (int) Math.floor(Math.random() * 9);
            	  	}
            	*/
            	if(num.count>=4)
            	{
            		if(num.count>=6)
            		{d=5;}
            		else
            		{d=10;}
            	}
                int x=target.getX()+a;//5�ȼ��� �̵�
                int y=target.getY()+b;
                          
                //������ ������ �������
                if(x>GamePanel.this.getWidth())
                	{
                	a=-5;
                    target.setLocation(GamePanel.this.getWidth(), y);
                    }
                //������ �ȿ� ������� 5�ȼ��� �̵�
                else
                    target.setLocation(x, y);
                
                if(x<0)
            	{
                	a=5;
                target.setLocation(5, y);}
                else
                    target.setLocation(x, y);
//////////////////////////////////////////////////////////////////////////////////////
                
                if(y>600)
            	{
            	b=-5;
                target.setLocation(x, 600);
                }
            //������ �ȿ� ������� 5�ȼ��� �̵�
            else
                target.setLocation(x, y);
            
            if(y<0)
        	{
            	b=5;
            target.setLocation(x, 0);}
            else
                target.setLocation(x, y);
            
            
////////////////////////////////////////////////////////////////////////////////////
                //0.02�ʸ��� �̵�
                try{
                    sleep(d);
                }
                //�����尡 �װԵǸ� �ʱ� ��ġ�� ��ġ�ϰ�, 0.5�ʸ� ��ٸ���.
                catch(Exception e){
                    target.setLocation(5, y);
                    num.point+=5;
                    timelimit-=10*num.e;
                	num.count++;
                    pointshow.setText("����:"+num.point);
                    try{
                        sleep(500);
                    }
                    catch(Exception e2){}
                }
            }
        }
        }
        
    }
    
    class TargetThread3 extends Thread{
        JLabel target;
        int d=20;
       
        int xx;
        int yy;
        TargetThread3(JLabel target){
        	int xx = (int) Math.floor(Math.random() * 800);
        	int yy = (int) Math.floor(Math.random() * 600);
            this.target=target;
            if(num.count==6) {target.setLocation(xx, yy);}
        }
        public void run(){
        	int a=40;
        	int b=40;
        	int d=50;
            while(true){
            	/*	
            	    if(c.count==6)
            	  	{
            	  	a = (int) Math.floor(Math.random() * 9);
            	  	}
            	*/
            	/*if(num.count>=4)
            	{
            		if(num.count>=6)
            		{d=5;}
            		else
            		{d=10;}
            	}*/
                int x=target.getX()+a;//5�ȼ��� �̵�
                int y=target.getY()+b;
                            
                //������ ������ �������
                if(x>GamePanel.this.getWidth())
                	{
                	a=-40;
                    target.setLocation(GamePanel.this.getWidth(), y);
                    }
                //������ �ȿ� ������� 5�ȼ��� �̵�
                else
                    target.setLocation(x, y);
                
                if(x<0)
            	{
                	a=40;
                target.setLocation(5, y);}
                else
                    target.setLocation(x, y);
//////////////////////////////////////////////////////////////////////////////////////
                
                if(y>600)
            	{
            	b=-40;
                target.setLocation(x, 600);
                }
            //������ �ȿ� ������� 5�ȼ��� �̵�
            else
                target.setLocation(x, y);
            
            if(y<0)
        	{
            	b=40;
            target.setLocation(x, 0);}
            else
                target.setLocation(x, y);
            
            
////////////////////////////////////////////////////////////////////////////////////
                //0.02�ʸ��� �̵�
                try{
                    sleep(d);
                }
                //�����尡 �װԵǸ� �ʱ� ��ġ�� ��ġ�ϰ�, 0.5�ʸ� ��ٸ���.
                catch(Exception e){
                    target.setLocation(5, y);
                    num.point+=100;
                	num.count++;
                    pointshow.setText("����:"+num.point);
                    try{
                        sleep(20);
                    }
                    catch(Exception e2){}
                }
            }
        }
    }
    
    class TargetThread4 extends Thread{
        JLabel target;
        int d=20;
       
        int xx;
        int yy;
        TargetThread4(JLabel target){
        	int xx = (int) Math.floor(Math.random() * 800);
        	int yy = (int) Math.floor(Math.random() * 600);
            this.target=target;
            if(num.count==4) {target.setLocation(xx, yy);}
        }
        public void run(){
        	int a=5;
        	int b=5;
        	int d=20;
            while(true){
            	/*	
            	    if(c.count==6)
            	  	{
            	  	a = (int) Math.floor(Math.random() * 9);
            	  	}
            	*/
            	/*if(num.count>=4)
            	{
            		if(num.count>=6)
            		{d=5;}
            		else
            		{d=10;}
            	}*/
                int x=target.getX()+a;//5�ȼ��� �̵�
                int y=target.getY();
                if(num.count>=2)
                {y=target.getY()+b;}                
                //������ ������ �������
                if(x>GamePanel.this.getWidth())
                	{
                	a=-5;
                    target.setLocation(GamePanel.this.getWidth(), y);
                    }
                //������ �ȿ� ������� 5�ȼ��� �̵�
                else
                    target.setLocation(x, y);
                
                if(x<0)
            	{
                	a=5;
                target.setLocation(5, y);}
                else
                    target.setLocation(x, y);
//////////////////////////////////////////////////////////////////////////////////////
                
                if(y>600)
            	{
            	b=-5;
                target.setLocation(x, 600);
                }
            //������ �ȿ� ������� 5�ȼ��� �̵�
            else
                target.setLocation(x, y);
            
            if(y<0)
        	{
            	b=5;
            target.setLocation(x, 0);}
            else
                target.setLocation(x, y);
            
            
////////////////////////////////////////////////////////////////////////////////////
                //0.02�ʸ��� �̵�
                try{
                    sleep(d);
                }
                //�����尡 �װԵǸ� �ʱ� ��ġ�� ��ġ�ϰ�, 0.5�ʸ� ��ٸ���.
                catch(Exception e){
                    target.setLocation(5, y);
                    num.point-=10;
                    timelimit=0;
                	num.count++;
                    pointshow.setText("����:"+num.point);
                    try{
                        sleep(500);
                    }
                    catch(Exception e2){}
                }
            }
        }
    }

    public class BulletThread extends Thread {
        JLabel bullet;
        JLabel target2 = new JLabel();
        JLabel target3 = new JLabel();
        JLabel target4 = new JLabel();
        JLabel[] target= new JLabel[num.enemy];
        Thread[] targetThread= new Thread[num.enemy];
        Thread targetThread2 =new Thread();
        Thread targetThread3 =new Thread();
        Thread targetThread4 =new Thread();
        int attack=0;
        
        public BulletThread(JLabel bullet, JLabel[] target, JLabel target2,JLabel target3,JLabel target4,Thread[] targetThread ,Thread targetThread2, Thread targetThread3, Thread targetThread4){
        	int a=0;
            this.bullet=bullet;
            
            for(int i=0;i<num.enemy;i++)
            {
            this.target[i]=target[i];
            this.targetThread[i]=targetThread[i];
            }
            this.targetThread2=targetThread2;
            this.targetThread3=targetThread3;
            this.targetThread4=targetThread4;
            this.target2=target2;
            this.target3=target3;
            this.target4=target4;
        }
    
        public void startGame2(){
        	if(num.count==2)
            {targetThread2.start();}
        	
        	if(num.count==6)
            { KillThread2();
           
            targetThread3.start();
            }
        	
        	if(num.count==4)
            {  
        		targetThread4.start();}
        }
        
        public void run(){
        	fired = true;
            while(true){
                if(hit()){//Ÿ���� �¾Ҵٸ�
                	if(attack<num.enemy)
                	{
                    targetThread[attack].interrupt();//Ÿ�� �����带 ���δ�.
                	}
                	if(attack==num.enemy)
                	{
                	targetThread2.interrupt();
                	}
                	if(attack==num.enemy+1)
                	{
                		num.count++;
                		both++;
                		
                		if(both==2) 
                		{
                		KillThread();
                		KillThread4();

                		timethread.stop();//killThread3();�����带 ����ϰ� ������ϳ׿�.timethread�ؿ� �־
                
           		     }
                	}
                	if(attack==num.enemy+2)
                	{
                	targetThread4.interrupt();
                	}
                    fired = false;
                   
                    //�Ѿ��� ���� ��ġ�� �̵�
                    startGame2();
                
                    //ioField.setText("����:"+num.point);
                    bullet.setLocation(base.getX()+15,base.getY()-10);
                  
                    return;//�Ѿ� �����嵵 ���δ�.
                }
                else{
                    int x=bullet.getX();
                    int y=bullet.getY()-5;//5�ȼ��� ���� �̵��Ѵ�.=�Ѿ� �ӵ��� 5�ȼ�
                    //�Ѿ��� ������ ������ ������ ��
                    if(y<0){
                        //�Ѿ� ���� ��ġ�� �̵�
                    	fired = false;
                    	bullet.setLocation(base.getX()+15,base.getY()-10);
                        return;//�Ѿ� �����带 ���δ�.
                    }
                    //�Ѿ��� ������ �ȿ� ������ 5�ȼ��� �̵��Ѵ�.
                    else
                    	bullet.setLocation(x,y);
                }
                //0.02�ʸ��� 5�ȼ��� �̵�
                try{
                    sleep(20);
                }
                
                catch(Exception e){}
            }
        }
        
        private boolean hit()
        {
            int x=bullet.getX();
            int y=bullet.getY();
            int w=bullet.getWidth();
            int h=bullet.getHeight();
            
            if(targetContains(x,y)
                    ||targetContains(x+w-1,y)
                    ||targetContains(x+w-1,y+h-1)
                    ||targetContains(x,y+h-1))
                return true;
            else
                return false;
        }
        
        
        private boolean targetContains(int x, int y){
            //Ÿ���� x��ǥ�� �Ѿ� x��ǥ���� �۰ų� ������ �Ѿ� x��ǥ���� Ÿ�� x��ǥ + Ÿ���� ���� ���̰� ũ��
            if(((target2.getX()<=x)&&(x<target2.getX()+target2.getWidth()))   
                    //Ÿ���� y��ǥ�� �Ѿ� y��ǥ���� �۰ų� ������ �Ѿ� y��ǥ���� Ÿ�� y��ǥ + Ÿ���� ���� ���̰� ũ��
                    &&((target2.getY()<=y)&&(y<target2.getY()+target2.getHeight())))
            {
            	
            	attack=num.enemy;
            	return true;
            	
            }
            	if(((target3.getX()<=x)&&(x<target3.getX()+target3.getWidth()))   
                        //Ÿ���� y��ǥ�� �Ѿ� y��ǥ���� �۰ų� ������ �Ѿ� y��ǥ���� Ÿ�� y��ǥ + Ÿ���� ���� ���̰� ũ��
                        &&((target3.getY()<=y)&&(y<target3.getY()+target3.getHeight())))
            	{
                	
                	attack=num.enemy+1;
                	return true;
                	
                }
            		if(((target4.getX()<=x)&&(x<target4.getX()+target4.getWidth()))   
                            //Ÿ���� y��ǥ�� �Ѿ� y��ǥ���� �۰ų� ������ �Ѿ� y��ǥ���� Ÿ�� y��ǥ + Ÿ���� ���� ���̰� ũ��
                            &&((target4.getY()<=y)&&(y<target4.getY()+target4.getHeight())))
            		 {
                    	
                    	attack=num.enemy+2;
                    	return true;
                    	
                    }
        	for(int i=0;i<num.enemy;i++)
        	{
            if(((target[i].getX()<=x)&&(x<target[i].getX()+target[i].getWidth()))   
                    //Ÿ���� y��ǥ�� �Ѿ� y��ǥ���� �۰ų� ������ �Ѿ� y��ǥ���� Ÿ�� y��ǥ + Ÿ���� ���� ���̰� ũ��
                    &&((target[i].getY()<=y)&&(y<target[i].getY()+target[i].getHeight())))
            {
            	
            
            	attack=i;
            	return true;
            	
            }
        	}
            
         
                return false;
        	
        	}
    
    }
    
    ///////////////////////////////////////
    public class BaseThread extends Thread // Base Thread Inner Class
	{
		JLabel base;
		JLabel bullet;
		public BaseThread(JLabel base, JLabel bullet)
		{
			this.base = base;
			this.bullet = bullet;
		}
		public void run()
		{
			int x, y;
			if(direction)
			{
				x = base.getX()+20;
				y = base.getY();
			}
			else
			{
				x = base.getX()-20;
				y = base.getY();
			}
			if(0<=x && x <=760)
				base.setLocation(x, y);
			
			if(!fired)
				bullet.setLocation(base.getX()+15,base.getY()-10);
		}
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		
		if(e.getKeyChar() == KeyEvent.VK_SPACE)
		{
			if(bulletThread == null || !bulletThread.isAlive())
			{
				bulletThread = new BulletThread(bullet,target,target2,target3,target4,targetThread,targetThread2,targetThread3,targetThread4);
				bulletThread.start();
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_LEFT)
		{
			direction = false;
			baseThread = new BaseThread(base,bullet);
			baseThread.start();
		}
		if(e.getKeyCode() == KeyEvent.VK_RIGHT)
		{
			direction = true;
			baseThread = new BaseThread(base,bullet);
			baseThread.start();
		}
	}
	@Override
	public void keyReleased(KeyEvent e) {}
	@Override
	public void keyTyped(KeyEvent e) {}
	

	/////////////////////
}
    



        

public class gametest extends number{

	gametest(int c) {
		super(c);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
    	
    
    	
    	Scanner scan = new Scanner(System.in); 
   	 System.out.println("0 1 2");
   	 int num = scan.nextInt(); 
   	 new gametest(num);
   	 
        new Ex5();
    }
}