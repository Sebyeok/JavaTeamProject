import java.util.Scanner;

public class Date {
	int month;
	int day;
	int year;
	Scanner input = new Scanner(System.in);
	static Date a =new Date();
	static Date b =new Date();
	private double age;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	a.readinput();
	a.writeOutput();
	
	}

	void SetMonth(int month)
	{
		this.month=month;
	}
	
	void SetDay(int day)
	{
		this.day=day;
	}
	void SetYear(int year)
	{
		this.year=year;
	}
	void readinput()
	{
		int c;
		int d;
		int e;
		System.out.println("���� ��¥�� �Է��ϼ���");
		c= input.nextInt();
		d= input.nextInt();
		e= input.nextInt();
		a.SetYear(c);
		a.SetMonth(d);
		a.SetDay(e);
		System.out.println("���� ������ �Է��ϼ���");
		c= input.nextInt();
		d= input.nextInt();
		e= input.nextInt();
		b.SetYear(c);
		b.SetMonth(d);
		b.SetDay(e);
	}
	void writeOutput() {
		System.out.println("���� ���̴�"+a.getAge(b)+"�Դϴ�.");
	}
	double getAge(Date b) 
	{
		
			if(this.month >= b.month)
			{
				if(this.month == b.month)
				{
					if(this.day >= b.day)
					{
					age= this.year-b.year+1;
					}
					else
					{
					age= this.year-b.year+2;
					}
				}
				else
				{
					age= this.year-b.year+1;
				}
			}
			else
			{
				age= this.year-b.year+2;
			}
		
		return age;
	}
	
}
