import java.util.Scanner;

public class game extends number{
            public void main(String[] args) {
            	
           
            	 Scanner scan = new Scanner(System.in); 
            	 int num = scan.nextInt(); 
            	 enemy = num;
                new Ex5();
            }
        }
            