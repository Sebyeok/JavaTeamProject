import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.*;

	
	class  implements ActionListener{
		public void actionPerformed(ActionEvent e) 
		{
		JButton button = (JButton) e.getSource();
		
		}
	}
	class MyFrame extends JFrame{
		private JButton button;
		public MyFrame() {
			this.setSize(2000,1000);
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			this.setTitle("Line War");
			this.setLayout(new BorderLayout());
			button = new JButton("���ӽ���");
			button.addActionListener(new MyListener());
			this.add(button, BorderLayout.SOUTH);
			this.setVisible(true);
		}
	}
	public class gametestmain{
	public static void main(String[] args)
	{
		MyFrame t = new MyFrame();
	}
	}


